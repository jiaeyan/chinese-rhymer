#!/usr/bin/env python
# -*- coding: utf-8 -*-

from chrhyme.ryhthm_generator import generate_rhythms


def main():
    generate_rhythms()


if __name__ == '__main__':
    main()
